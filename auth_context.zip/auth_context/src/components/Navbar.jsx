import {Login} from './Login'
export const Navbar = () => {
    return (
         
         <div>
             
             <input type="text" placeholder="Enter Your name" /> 
            <input type="submit" value="Submit" />
            <Login/>
         </div>
     )
 }