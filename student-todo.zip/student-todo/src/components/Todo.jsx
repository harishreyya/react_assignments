import { useEffect, useState } from "react"


export const Todo =()=>{

    const [todos,setTodos] = useState([]);
    const [text,setText] = useState("");
    const [loading,setLoading] = useState(false)
    const [page,setPage] = useState(1)
  useEffect(()=>{
      getData()
    },[page])

    const getData = () =>{
        setLoading(true)
        fetch(`http://localhost:3001/todos?_page=${page}&_limit=3`).then(d=>d.json()).then(res=>{
            setTodos(res)
            setLoading(false)
        })
    }
    return loading ? ("loading..." 
    ): (
    <div>
        <input 
        className="inputTitle"
        placeholder="Add todos..." 
        onChange={(e) => setText(e.target.value)}
        />
        
       
        <button onClick={() => {
            const data = {status : false ,title: text}
            fetch("http://localhost:3001/todos",{
                method:"POST",
                body: JSON.stringify(data),
                headers:{
                    "content-type":"application/json"
                },
            }).then(getData)
            //   setTodos([...todos,{status : false ,title: text}])
        }}>ADD</button> 
       
        {todos.map(e => <div className="todoItem" key={e.id}>{e.title} - {e.status ? "done"  : "not done" }</div>)} 

        <input placeholder="Add Task..." className="inputBody"
         />
        <button onClick={()=>{
            setPage(page - 1)
        }}
        >prev</button>
        <button onClick={()=>{
            setPage(page + 1)
        }}
        >next</button>
        </div>

        ) 
   
}