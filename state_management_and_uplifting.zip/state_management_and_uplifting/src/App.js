import { Grocery} from "./components/stores/Grocery"
import './App.css';

function App() {
  return (
    <div className="App">
     <h1>Groceries to be picked</h1>
     <  Grocery/>
    </div>
  );
}

export default App;