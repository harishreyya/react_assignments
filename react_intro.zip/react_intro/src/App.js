import logo from './logo.svg';
import './App.css';
function App() {
  const style = {
 marginLeft: "540px"
    
  }
  return (
    
      <div style={style} >
      <h1>Mobile Operating System</h1>
      <ul>
        <li>Android</li>
        <li>BlackBerry</li>
        <li>iPhone</li>
        <li>Windows Phone</li>
      </ul>
      
        <h1>Mobile Manufacturers</h1>
      <ul>
        <li>Samsung</li>
        <li>HTC</li>
        <li>Micromax</li>
        <li>Apple</li>
      </ul>
      </div>
   
  );
}

export default App;
